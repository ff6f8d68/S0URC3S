Ce paramètre détermine le nombre de ticks que prendra l'entité pour passer d'une animation à une autre.
Si vous augmentez cette valeur, la transition sera plus douce, tandis que si vous la diminuez, la transition sera moins douce.
Pour désactiver complètement les transitions, réglez cette valeur sur zéro.