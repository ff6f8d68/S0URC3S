<h3 style="margin-top:0;">Structure Spread:<br>( Currently unavailable )</h3>

- <b>Random spread (Default)</b>: This will be used in tandem with spacing between structure spawns; This will allow your structures to spawn similar to Swamp Huts, Bastion Remnants, Ocean Monuments and Villages.

- <b>Concentric rings</b>: Spawn distribution similar to Stronghold generation.