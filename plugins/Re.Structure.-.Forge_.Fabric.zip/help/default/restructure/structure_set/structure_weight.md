<h3 style="margin-top:0;">Structure Weight:<br>( Currently unavailable )</h3>

- <b>Weight (Default: 1):</b> Determines the chance of this structure being chosen over others.<br>

  - <b>Note:</b> Must be a positive integer.