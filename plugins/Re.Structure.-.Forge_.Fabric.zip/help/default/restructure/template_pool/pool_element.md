<h3 style="margin-top:0;">Template Pool Element Type:<br>( Currently unavailable )</h3>

- <b>Empty</b>: This will generate an empty structure pool; generating nothing.

- <b>Feature:</b> This will generate a placed feature.

- <b>List:</b> This will generate multiple elements one after another.<br>

  - ( Lower elements are replaced by their front elements )

- <b>Legacy:</b> Generates a normal structure template

- <b>Single (Default):</b> Generates a normal structure template. 

<b>NOTE:</b> The difference between a <b>Legacy</b> and <b>Single</b> pool template element is that Legacy elements will not replace existing blocks with air, and single elements will replace blocks with air and relies on structure void blocks to avoid not replacing blocks.