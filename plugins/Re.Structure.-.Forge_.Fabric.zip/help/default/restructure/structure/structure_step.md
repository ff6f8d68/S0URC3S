<h3 style="margin-top:0;">Structure Generation type:<br>( Currently unavailable )</h3>
There are a total of 11 different types of structure generation, but 10 types to choose from.

- <b>Fluid springs:</b> This generation type is used for water and lava springs.

- <b>Lakes:</b> This generation type is used by lava lakes.

- <b>Local modifications:</b> This generation type is used by amethyst geodes and icebergs.

- <b>Raw generation:</b> This generation type is used for small end island features/

- <b>Surface structures (Default):</b> Used primarily for structures that spawn on the surface of the Overworld, Nether and End.

- <b>Top layer modification:</b> This generation type is used for surface freezing in vanilla.

- <b>Underground decoration:</b> This generation type is used for infested block blobs, Nether gravel and Blackstone blobs, and all Nether ore blobs.

- <b>Underground ores:</b> This generation type is used for Overworld ore blobs; including Dirt, Gravel, Stone variant blobs, and Sand, Gravel and Clay disks. 

- <b>Underground structures:</b> This generation type is used for dungeons and Overworld fossils.

- <b>Vegetal decoration:</b> This generation type is used for Trees, Bamboo, Cacti, Kelp, and other ground / ocean vegetation. 