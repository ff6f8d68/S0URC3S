<h3 style="margin-top:0;">Height Adjustment:</h3>

- This can be used to offset the height of the structure spawned relative to the ground.

  - <b>Default:</b> 0

<b>NOTE:</b> If your structure spawns in the Nether, set the Heightmap to <b>"NONE"</b> and set this value to a negative number; otherwise, the structure will spawn on the Nether bedrock ceiling.

- When accompanied by <b>WORLD SURFACE WG</b> in the Structure Heightmap, this will allow the structure to float in the air if set to a positive number; otherwise, it will stay on the ground level and can be set as a negative number to sink the structure into the ground.

- When accompanied by <b>OCEAN FLOOR WG</b> in the Structure Heightmap, this will allow the structure to either rise towards the surface of the water if set to a positive number or sink into the ocean floor if set to a negative number.
