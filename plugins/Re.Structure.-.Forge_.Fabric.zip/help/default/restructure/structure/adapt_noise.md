<h3 style="margin-top:0;">Terrain Adaptation:</h3>

- When **Enabled** this will allow structures to generate with terrain underneath them.