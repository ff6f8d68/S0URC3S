<h3 style="margin-top:0;">Selected / Imported Structure:</h3>
This is the structure specified to spawn in the world.