<h3 style="margin-top:0;">Expansion Hack:</h3>
Villages use this for fixes on their streets in vanilla generation.

- Used <b>only</b> when generating villages, or village like structures.