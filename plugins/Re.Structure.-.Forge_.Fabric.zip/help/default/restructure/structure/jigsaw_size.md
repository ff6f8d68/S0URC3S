<h3 style="margin-top:0;">Jigsaw block size generation:</h3>
Generally used if there are Jigsaw blocks within your structure.

- This is the depth of a <b>Jigsaw structure</b> to generate.

- <b>Default: 1</b>  

  - Values between 1 - 7.