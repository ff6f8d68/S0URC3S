<h3 style="margin-top:0;">Terrain Adaptation:</h3>
Terrain adaptation controls how the structure will affect the surrounding terrain.

- <b>Beard box</b>: Generally used for Ancient Cities. Will affect the terrain around the structure greatly; A stronger version of <b>Beard thin</b>.
- <b>Beard thin</b>: Adds terrain below the structure; used by Villages and Pillager Outposts.
- <b>Bury</b>: Used primarily by Strongholds; greatly accompanied by <b>"NONE"</b> in Structure Heightmap.
- <b>None (Default)</b>: Does not affect the surrounding terrain.