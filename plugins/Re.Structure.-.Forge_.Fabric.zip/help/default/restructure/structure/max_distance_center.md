<h3 style="margin-top:0;">Max distance from center:</h3>

- The maximum distance that a <b>Jigsaw structure</b> can branch out.