<h3 style="margin-top:0;">Terrain Adaptation:</h3>
Terrain adaptation controls how the structure will affect the surrounding terrain.

- <b>Enabled</b>: Add extra terrain below each structure piece.