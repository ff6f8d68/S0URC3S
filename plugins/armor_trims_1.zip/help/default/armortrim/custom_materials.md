This is a list of items that can be used in the smithing recipe along with the smithing template in order to apply the custom armor
trim to the armor. These do not affect the color of the armor trim.